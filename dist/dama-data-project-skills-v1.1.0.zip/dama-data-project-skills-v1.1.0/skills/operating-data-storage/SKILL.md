---
name: operating-data-storage
description: Use when a database, lake, warehouse, file store, or other persisted-data service needs production readiness, environment and change control, capacity, performance, availability, backup/recovery, retention/disposal, monitoring, or operational handoff.
---

# 数据存储与运行

## 核心原则

数据存储与运行负责设计、实施和支持持久化数据，使其在全生命周期内可用、完整、可恢复且性能可接受。平台已选或备份作业成功都不等于生产就绪；必须用端到端演练证实服务目标。

## 适用边界

- 数据库/存储技术评估、实例与环境、物理运行、变更发布、容量、性能、可用性、备份恢复、保留处置和移交使用本技能。
- 企业目标/过渡架构和跨系统蓝图由 `designing-data-architecture` 主导。
- 实体、属性、键和逻辑/物理模型语义由 `modeling-data` 主导；本技能验证可运维性。
- 接口、批流编排、重放与跨系统对账由 `integrating-data` 主导。
- 分类、授权和保护控制由 `securing-data` 主导；本技能落实数据库配置与运行证据。

## 工作流

1. 明确业务服务、数据重要性、消费者、服务时段、关键窗口、工作负载、增长、保留和合规约束。
2. 阅读[数据存储与运行手册](references/playbook.md)，建立服务目录、依赖/故障模型、环境与责任边界；托管服务责任不得假定为端到端责任。
3. 由业务影响和实测证据批准 SLI/SLO、可用性、RTO/RPO、性能、容量、成本、事件分级与降级方式。
4. 建立开发、测试、预生产、生产及恢复环境；所有配置、模式与数据变更可重复、经测试、可审计且有前滚/回退。
5. 实施备份、恢复、复制/故障转移、保留/归档/处置、监控、告警和值班；备份必须恢复并校验，HA 不代替备份或 DR。
6. 用代表性规模做基线、峰值、耐久、故障、恢复、权限和生命周期测试；任何硬门缺证据则 No-Go 或缩小范围。
7. 将 runbook、仪表盘、资产、支持链路和运行日历交给具名团队；持续监控容量、性能、变更、事件、恢复与成本。

## 交付模板

使用 [中文交付包](templates/delivery-pack.zh.md) 或 [English delivery pack](templates/delivery-pack.en.md) 组织输出。叙述性方案和评审记录使用同目录 Word 模板；矩阵、台账和评分卡使用同目录 Excel 模板。模板中的责任、阈值、批准和证据须由实际项目确认。

## 输出契约

输出服务范围和依赖；环境/配置基线；技术适配与物理运行设计；容量/成本；SLO、RTO/RPO；备份恢复与生命周期；变更发布；监控告警与事件；runbook、值班和移交；测试证据、风险、Go/No-Go 及后续运行日历。

## 常见错误

| 错误 | 修正 |
|---|---|
| 云/托管即高可用 | 验证身份、网络、密钥、调度、连接和消费者的端到端恢复 |
| 备份成功即安全 | 从隔离副本实际恢复，并做结构、权限和业务对账 |
| 只按主表估算容量 | 包含索引、日志、暂存、副本、时间旅行、备份和增长裕度 |
| 生产变更现场手工修补 | 受控脚本、低环境验证、批准、观测和前滚/回退 |
| 文档移交等于接管 | 由未来值班人员独立演练并签署接管 |
